﻿using Microsoft.Data.SqlClient;
using ProjetoMercado.Context;
using ProjetoMercado.Models;
using Microsoft.EntityFrameworkCore;
using ProjetoMercado.Repositorio;

namespace ProjetoMercado.Repositorio
{
    public class CrudProdutos: ICrudProdutos
    {
        private readonly AppDbContext _context;

        public CrudProdutos(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Tb_Produtos>> GetProdutosListAsync()
        {
            return await _context.Tb_Produtos
                .FromSqlRaw<Tb_Produtos>("sp_GetprodutosList")
                .ToListAsync();
        }

        public async Task<IEnumerable<Tb_Produtos>> GetProdutoByProdutoIDAsync(int ProdutoID)
        {
            var param = new SqlParameter("@ProdutoID", ProdutoID);

            var produto = await Task.Run(() => _context.Tb_Produtos
                            .FromSqlRaw(@"exec GetProdutosByProdutoID @ProdutoID", param).ToListAsync());

            return produto;
        }


        public async Task<int> UpdateProdutoAsync(Tb_Produtos produto)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@ProdutoID", produto.ProdutoID));
            parameter.Add(new SqlParameter("@NomeProduto", produto.NomeProduto));
            parameter.Add(new SqlParameter("@DataProduto", produto.DataProduto));
            var result = await Task.Run(() => _context.Database
            .ExecuteSqlRawAsync(@"exec UpdateProduto @ProdutoID, @NomeProduto, @DataProduto", parameter.ToArray()));
            return result;
        }
        public async Task<int> DeleteProdutoAsync(int ProdutoID)
        {
            return await Task.Run(() => _context.Database.ExecuteSqlInterpolatedAsync($"DeleteProdutosByID {ProdutoID}"));
        }

        public async Task<int> AddProdutoAsync(Tb_Produtos produtos)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@ProdutoID", produtos.ProdutoID));
            parameter.Add(new SqlParameter("@NomeProduto", produtos.NomeProduto));
            parameter.Add(new SqlParameter("@PrecoDeCusto", produtos.PrecoDeCusto));
            parameter.Add(new SqlParameter("@Categoria", produtos.Categoria));
            parameter.Add(new SqlParameter("@Fornecedor", produtos.Fornecedores));


            var result = Task.Run(() => _context.Database
           .ExecuteSqlRawAsync(@"exec sp_AddProduto @ProdutoID, @NomeProduto, @PrecoDeCusto, @Categoria, @Fornecedor", parameter.ToArray()));

            return await result;
        }
    }
}
