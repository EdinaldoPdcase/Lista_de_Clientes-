﻿using ProjetoMercado.Models;
using ProjetoMercado.Context;

namespace ProjetoMercado.Repositorio
{
    public interface ICrudProdutos
    {
        public Task<List<Tb_Produtos>> GetProdutosListAsync();
        public Task<IEnumerable<Tb_Produtos>> GetProdutoByProdutoIDAsync(int ProdutoID);
        public Task<int> AddProdutoAsync(Tb_Produtos produtos);
        public Task<int> UpdateProdutoAsync(Tb_Produtos produtos);
        public Task<int> DeleteProdutoAsync(int ProdutoID);



    }
}
