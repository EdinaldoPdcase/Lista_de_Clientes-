﻿using LabCliente.Models;
using Microsoft.EntityFrameworkCore;


namespace LabCliente.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }
        public virtual DbSet<Cliente> Cliente { get; set; }
        public virtual DbSet<Cidade> Cidade { get; set; }

        public DbSet<Cliente> Clientes { get; set; }


    }
}


