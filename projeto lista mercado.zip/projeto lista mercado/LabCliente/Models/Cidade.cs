﻿using System.ComponentModel.DataAnnotations;

namespace LabCliente.Models
{
    public class Cidade
    {
        [Key]
        public int CidadeID { get; set; }
        [Display(Name = "Nome da Cidade")]
        [Required(ErrorMessage = "Informe o nome da cidade")]
        [StringLength(38, ErrorMessage = "O tamanho máximo é  caracteres")]
        public string CidadeNome { get; set; }
        [Display(Name = "UF")]
        [Required(ErrorMessage = "Informe o UF da cidade")]
        [StringLength(2, ErrorMessage = "O tamanho máximo é  caracteres")]
        public string CidadeUF { get; set; }
      
        
        
    }
}
