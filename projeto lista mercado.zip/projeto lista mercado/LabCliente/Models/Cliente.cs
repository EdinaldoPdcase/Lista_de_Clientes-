﻿using LabCliente.ViewModels;
using System.ComponentModel.DataAnnotations;

namespace LabCliente.Models
{
    public class Cliente
    {
        internal string CidadeNome { get; set; }

        [Key]
        public int ClienteID { get; set; }
        [Display(Name = "Nome")]
        [Required(ErrorMessage = "Informe o nome do cliente")]
        [StringLength(60, ErrorMessage = "O tamanho máximo é  caracteres")]
        public string Nome { get; set; }
        [Required]
        public System.DateTime Nascimento { get; set; }

        [Display(Name = "CPF")]
        [RegularExpression(@"^(\d{3}.\d{3}.\d{3}-\d{2})|(\d{11})*$")]
        [MinLength(14, ErrorMessage = "menor que 15")]
        [StringLength(14, ErrorMessage = "O tamanho máximo é 14 caracteres")]
        [DisplayFormat(DataFormatString = "{0:###.###.###.##}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Informe o cpf")]
        public string CPF { get; set; }
        [StringLength(9, ErrorMessage = "O tamanho máximo é 9 caracteres")]
        public string Sexo { get; set; }
        public int Idade { get; set; }
        

        public int CidadeID { get; set; }
        //public List<Cidade> Cidade{ get; set; }
    }
}
