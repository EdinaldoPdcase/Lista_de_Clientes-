﻿using LabCliente.Models;

namespace LabCliente.ViewModels
{
    public class CidadeViewModel
    {
        public Cidade Cidade { get; set; }
    }
}
