﻿using LabCliente.Models;

namespace LabCliente.ViewModels
{
    public class ClienteViewModel
    {
        public ICollection<Cliente> Clientes { get; set; }

        // Essa é a região de Filtro é nessas propriedades que serão feito os Binds ou Asp-For

        
        public Cliente Cliente { get; set; }
        public IEnumerable<Cliente> ClienteID { get; set; }
        public IEnumerable<Cliente> CPF { get; set; }
        public List<Cliente> Nome { get; set; }
        public List<Cidade> CidadeNome { get; set; }

        public string Filter { get; set; }
        

        

    }
}
