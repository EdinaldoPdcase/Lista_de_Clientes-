﻿using LabCliente.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Hosting;

namespace LabCliente.ViewModels
{
    public class ListViewModel
    {

        public Cliente ClienteID { get; set; }
        public  Cidade CidadeID { get; set; }
        public Cliente CPF { get; set; }
        public IEnumerable<Cliente> Nome { get; set; }
        public IEnumerable<Cliente> Nascimento { get; set; }
        public IEnumerable<Cliente> Sexo { get; set; }
        public Cliente Idade { get; set; }
        public Cidade CidadeNome { get; set; }
        public Cidade CidadeUF{ get; set; }
        public string Filter { get; set; }
        public IEnumerable<Cliente> Cliente { get; set; }
        public IEnumerable<Cliente> Clientes { get; set; }
        public IEnumerable<Cidade> Cidade { get; set; }
        public List<SelectListItem> Client { get; set; }

        
    }
}