﻿using LabCliente.Models;

namespace LabCliente.ViewModels
{
    public class ListCidadeViewModel
    {

        
        public Cidade CidadeID { get; set; }
     
     
        public Cidade CidadeNome { get; set; }

        public Cidade CidadeUF { get; set; }
        public string Filter { get; set; }
       
        public IEnumerable<Cidade> Cidade { get; set; }
       
    }
}
