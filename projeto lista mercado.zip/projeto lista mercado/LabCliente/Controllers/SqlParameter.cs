﻿namespace LabCliente.Controllers
{
    internal class SqlParameter
    {
        private string v;
        private string cidadeUF;

        public SqlParameter(string v, string cidadeUF)
        {
            this.v = v;
            this.cidadeUF = cidadeUF;
        }
    }
}