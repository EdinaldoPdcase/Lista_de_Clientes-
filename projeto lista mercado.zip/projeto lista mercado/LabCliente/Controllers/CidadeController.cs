﻿using LabCliente.Context;
using LabCliente.Models;
using LabCliente.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace LabCliente.Controllers
{
    public class CidadeController : Controller
    {
        private readonly AppDbContext _context;

        public CidadeController(AppDbContext context)
        {
            _context = context;
        }

        // GET: HomeController1
        public ActionResult Index(ListViewModel CliVM, string Filter, string CidadeNome)
        {




            if (string.IsNullOrWhiteSpace(Filter))
            {
                /*var clientes = this._context.Cidade.Select(s => new
           {
               CidadeID = s.CidadeID,
               CidadeNome = s.CidadeNome
           }).ToList();*/
                //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
                //ViewBag.CidadeID = new SelectList(clientes, "CidadeID", "CidadeID");
                // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID","CidadeNome", "CidadeNome", "CidadeID");
                // var query = from m in _context.Cliente.Where(p => p.Nome.Contains(ViewBag.CidadeID))
                var query = from m in _context.Cidade
                          
                    
                            where
                           ((CliVM.CidadeID == null)) 
                                      
                       
                                     && ((CliVM.CidadeNome == null))
                                       && ((CliVM.CidadeUF == null))

                            select new
                            {
                                CidadeID = m.CidadeID,
                              
                             
                                CidadeNome = m.CidadeNome,
                                CidadeUF = m.CidadeUF

                            };
                List<Cidade> listaClientes = new List<Cidade>();
                foreach (var reg in query)
                {
                    Cidade clientevalor = new Cidade();
                    clientevalor.CidadeID = reg.CidadeID;
                    clientevalor.CidadeNome = reg.CidadeNome;
                    clientevalor.CidadeUF = reg.CidadeUF;
                    listaClientes.Add(clientevalor);
                }
                CliVM.Cidade = listaClientes;
                return View(CliVM);

            }
            else
            {
               // var query = _context.Cidade.Where(p => p.CidadeNome.Contains(Filter));
                var query = _context.Cidade
    .FromSql($"EXECUTE dbo.sp_GetCidade  {Filter}")
    .ToList();

                List<Cidade> listaClientes = new List<Cidade>();
                foreach (var reg in query)
                {
                    Cidade clientevalor = new Cidade();
                    clientevalor.CidadeID = reg.CidadeID;
                    clientevalor.CidadeNome = reg.CidadeNome;
                    clientevalor.CidadeUF = reg.CidadeUF;
                    listaClientes.Add(clientevalor);
                }
                CliVM.Cidade = listaClientes;
                return View(CliVM);
            }


            /*
            if (string.IsNullOrWhiteSpace(Filter))
            {
              
                
                var queri = this._context.Cidade.Select(s => new
                {
                    CidadeID = s.CidadeID,
                    CidadeNome = s.CidadeNome,
                    CidadeUF= s.CidadeUF
                }).ToList();
                ViewBag.CidadeID = new SelectList((System.Collections.IEnumerable)queri, "CidadeID", "CidadeNome", "CidadeNome", "CidadeID");

                List<Cidade> listaClientes = new List<Cidade>();
                foreach (var reg in queri)
                {
                    Cidade clientevalor = new Cidade();
                    clientevalor.CidadeID = reg.CidadeID;
                    clientevalor.CidadeNome = reg.CidadeNome;
                    clientevalor.CidadeUF = reg.CidadeUF;


                    listaClientes.Add(clientevalor);
                }
                CliVM.Cidade = listaClientes;
                return View(CliVM);
                //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
                //ViewBag.CidadeID = new SelectList(clientes, "CidadeID", "CidadeID");
               

                //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
                // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID", "CidadeNome");
                //ViewBag.CidadeID = new SelectList((System.Collections.IEnumerable)queri, "CidadeNome", "CidadeID");

                /*var clientes = this._context.Cidade.Select(s => new
           {
               CidadeID = s.CidadeID,
               CidadeNome = s.CidadeNome
           }).ToList();*/
            //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
            //ViewBag.CidadeID = new SelectList(clientes, "CidadeID", "CidadeID");
            // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID","CidadeNome", "CidadeNome", "CidadeID");
            // var query = from m in _context.Cliente.Where(p => p.Nome.Contains(ViewBag.CidadeID))




            /*  

           }
           else
           {
               var query = _context.Cidade
   .FromSql($"EXECUTE dbo.sp_GetCidade  {Filter}")
   .ToList();

               List<Cidade> listaClientes = new List<Cidade>();
               foreach (var reg in query)
               {
                   Cidade clientevalor = new Cidade();
                   clientevalor.CidadeID = reg.CidadeID;
                   clientevalor.CidadeNome = reg.CidadeNome;
                   clientevalor.CidadeUF = reg.CidadeUF;


                   listaClientes.Add(clientevalor);
               }
               CliVM.Cidade = listaClientes;
               return View(CliVM);
           }
           */


        }

        // GET: HomeController1/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: HomeController1/Create
        public ActionResult Create()
        {
           
            return View();
        }

        // POST: HomeController1/Create
        [HttpPost]
        public async Task<IActionResult> Create([Bind("CidadeNome, CidadeUF")] Cidade cidade)
        {
            if (ModelState.IsValid)
            {

                

                    var parameter = new List<SqlParameter>();
                    parameter.Add(new SqlParameter("@NomeCidade", cidade.CidadeNome));
                    parameter.Add(new SqlParameter("@CidadeUF", cidade.CidadeUF));


                var result = await Task.Run(() => _context.Database
                   .ExecuteSqlRawAsync(@"exec dbo.sp_CadCidade @NomeCidade, @CidadeUF", parameter.ToArray()));

                    return RedirectToAction("Index");

                }
            
            return View();
        }

        // GET: Compras1/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Cidade == null)
            {
                return NotFound();
            }

            var compra = await _context.Cidade.FindAsync(id);
            if (compra == null)
            {
                return NotFound();
            }
            return View(compra);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CidadeNome,CidadeUF")] Cidade cidade)
        {
            if (id != cidade.CidadeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cidade);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CidadeExists(cidade.CidadeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cidade);
        }

        // GET: HomeController1/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: HomeController1/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HomeController1/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: HomeController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        private bool CidadeExists(int id)
        {
            return _context.Cidade.Any(e => e.CidadeID == id);
        }
    }
}
