﻿using LabCliente.Context;
using LabCliente.Models;
using LabCliente.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using LabCliente.Services;
using System.Windows.Forms;
using BoldReports.Models.ReportViewer;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace LabCliente.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        
        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        

        public ActionResult Index1()
        {
            ViewBag.ClienteID = new SelectList(_context.Cliente, "ClienteID", "Nome");
            
            return View();
        }
        public IActionResult Index(ListViewModel CliVM, string Filter)
        {


            

            if (string.IsNullOrWhiteSpace(Filter))
            {
                 /*var clientes = this._context.Cidade.Select(s => new
            {
                CidadeID = s.CidadeID,
                CidadeNome = s.CidadeNome
            }).ToList();*/
            //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
            //ViewBag.CidadeID = new SelectList(clientes, "CidadeID", "CidadeID");
           // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID","CidadeNome", "CidadeNome", "CidadeID");
               // var query = from m in _context.Cliente.Where(p => p.Nome.Contains(ViewBag.CidadeID))
               var query = from m in _context.Cliente
                            join n in _context.Cidade
                            on m.CidadeID equals
                                n.CidadeID
                            where
                           ((CliVM.ClienteID == null)) &&
                                      ((CliVM.CPF == null)) &&

                           ((CliVM.Nome == null))
                                     && ((CliVM.CidadeNome == null))

                            select new
                            {
                                ClienteID = m.ClienteID,
                                CPF = m.CPF,
                                Nome = m.Nome,
                                CidadeNome = n.CidadeNome
                                
                            };
                List<Cliente> listaClientes = new List<Cliente>();
                foreach (var reg in query)
                {
                    Cliente clientevalor = new Cliente();
                    clientevalor.ClienteID = reg.ClienteID;
                    clientevalor.CPF = reg.CPF;
                    clientevalor.Nome = reg.Nome;
                    clientevalor.CidadeNome = reg.CidadeNome;
                    listaClientes.Add(clientevalor);
                }
                CliVM.Clientes = listaClientes;
                return View(CliVM);

            }
            else
            {
                var query = _context.Cliente
    .FromSql($"EXECUTE dbo.sp_GetCliente  {Filter}")
    .ToList();
               
                List<Cliente> listaClientes = new List<Cliente>();
                foreach (var reg in query)
                {
                    Cliente clientevalor = new Cliente();
                    clientevalor.ClienteID = reg.ClienteID;
                    clientevalor.CPF = reg.CPF;
                    clientevalor.Nome = reg.Nome;
                    clientevalor.CidadeNome = reg.CidadeNome;
                    
                    listaClientes.Add(clientevalor);
                }
                CliVM.Clientes = listaClientes;
                return View(CliVM);

            }
        }

        // GET: Produtoes/Create
        public IActionResult Create()
        {
            var clientes = this._context.Cidade.Select(s => new
            {
                CidadeID = s.CidadeID,
                CidadeNome = s.CidadeNome
            }).ToList();
            //ViewData["CidadeNome"] = new SelectList(clientes, "CidadeID", "CidadeNome");
            //ViewBag.CidadeID = new SelectList(clientes, "CidadeID", "CidadeID");
            ViewBag.CidadeID = new SelectList(clientes, "CidadeID","CidadeNome", "CidadeNome", "CidadeID");
            //ViewBag.ClienteID = new SelectList(_context.Cliente, "CidadeeID", "Nome");
            // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID", "CidadeID");
            return View();
        }

        // POST: Produtoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Create(ListViewModel CliVM, [Bind("Nome,CidadeID,Nascimento,CPF,Sexo,Idade")] Cliente cliente)
        {
            
           
            if (ModelState.IsValid)
            {
                _context.Add(cliente);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            // ViewBag.CidadeID = new SelectList(_context.Cidade, "CidadeID", "CidadeID");
            var query = from m in _context.Cliente
                        join n in _context.Cidade
                        on m.CidadeID equals
                            n.CidadeID
            where
                       ((CliVM.ClienteID == null)) &&
                                  ((CliVM.CPF == null)) &&

                       ((CliVM.Nome == null))
                                 && ((CliVM.CidadeNome == null))

                        select new
                        {
                            ClienteID = m.ClienteID,
                            CPF = m.CPF,
                            Nome = m.Nome,
                            CidadeNome = n.CidadeNome

                        };
            List<Cliente> listaClientes = new List<Cliente>();
            foreach (var reg in query)
            {
                Cliente clientevalor = new Cliente();
                clientevalor.ClienteID = reg.ClienteID;
                clientevalor.CPF = reg.CPF;
                clientevalor.Nome = reg.Nome;
                clientevalor.CidadeNome = reg.CidadeNome;
                listaClientes.Add(clientevalor);
            }
            CliVM.Clientes = listaClientes;
            return View(CliVM);
           
            /*
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@Nome", cliente.Nome));
            parameter.Add(new SqlParameter("@Nascimento", cliente.Nascimento));
            parameter.Add(new SqlParameter("@CPF", cliente.CPF));
            parameter.Add(new SqlParameter("@Sexo", cliente.Sexo));
            parameter.Add(new SqlParameter("@Idade", cliente.Idade));
            parameter.Add(new SqlParameter("@CidadeID", cliente.CidadeID));
            var result = await Task.Run(() => _context.Database
            .ExecuteSqlRawAsync(@"exec sp_CadCliente @Nome, @Nascimento, @CPF, @Sexo, @Idade, @CidadeID", parameter.ToArray()));


            return View();
         */

        }
        public ActionResult Cria()
        {

            return View();
        }

        // POST: HomeController1/Create
        [HttpPost]
        public async Task<IActionResult> Cria([Bind("CidadeNome, CidadeUF")] Cidade cidade)
        {
            if (ModelState.IsValid)
            {



                var parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("@NomeCidade", cidade.CidadeNome));
                parameter.Add(new SqlParameter("@CidadeUF", cidade.CidadeUF));


                var result = await Task.Run(() => _context.Database
                   .ExecuteSqlRawAsync(@"exec dbo.sp_CadCidade @NomeCidade, @CidadeUF", parameter.ToArray()));

                return RedirectToAction("Index");

            }

            return View();
        }
        // GET: Compras/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null)
            {
                return NotFound();
            }

            var cliente = await _context.Cliente
                
                .FirstOrDefaultAsync(m => m.ClienteID == id);
            if (cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        // POST: Compras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditPost(int? id, string CPF)
        {
           
             
            
                int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                string tempCpf;
                string digito;
                int soma;
                int resto;
            string CPF1;
                CPF1 = CPF.Trim();
                CPF1 = CPF.Replace(".", "").Replace("-", "");

            if (CPF1.Length != 11)
            {
                return View() ;
            }
                tempCpf = CPF1.Substring(0, 9);
                soma = 0;
                for (int i = 0; i < 9; i++)
                    soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

                resto = soma % 11;
                if (resto < 2)
                    resto = 0;
                else
                    resto = 11 - resto;

                digito = resto.ToString();

                tempCpf = tempCpf + digito;

                soma = 0;
                for (int i = 0; i < 10; i++)
                    soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

                resto = soma % 11;
                if (resto < 2)
                    resto = 0;
                else
                    resto = 11 - resto;

                digito = digito + resto.ToString();

                 
            

           
                if (CPF1.EndsWith(digito))
                {
                return View();
                }
               
         
        

       

            if (id == null)
            {
                return NotFound();
            }

            var instructorToUpdate = await _context.Cliente
              
                .FirstOrDefaultAsync(s => s.ClienteID == id);

            if (await TryUpdateModelAsync<Cliente>(
                instructorToUpdate,
                "",
                i => i.CidadeID, i => i.Nome, i => i.Nascimento, i => i.CPF, i => i.Sexo, i => i.Idade))
            {
                if (instructorToUpdate.ClienteID==0)
                {
                    return NotFound();
                }
                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException /* ex */)
                {
                    //Log the error (uncomment ex variable name and write a log.)
                    ModelState.AddModelError("", "Unable to save changes. " +
                        "Try again, and if the problem persists, " +
                        "see your system administrator.");
                }
                return RedirectToAction(nameof(Index));
            }
            return View(instructorToUpdate);
        }

        // GET: Compras/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Cliente == null)
            {
                return NotFound();
            }

            var compra = await _context.Cliente
                .FirstOrDefaultAsync(m => m.ClienteID == id);
            if (compra == null)
            {
                return NotFound();
            }

            return View(compra);
        }

        // POST: Compras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Cliente == null)
            {
                return Problem("Entity set 'AppDbContext.Compra'  is null.");
            }
            var compra = await _context.Cliente.FindAsync(id);
            if (compra != null)
            {
                _context.Update(compra);
                _context.Cliente.Remove(compra);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClienteExists(int id)
        {
            return _context.Cliente.Any(e => e.ClienteID == id);
        }
        


    }
}