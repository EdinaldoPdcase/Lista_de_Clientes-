﻿using LabCliente.Context;
using LabCliente.Services;
using Microsoft.AspNetCore.Mvc;
using FastReport.Export.PdfSimple;
using System.Diagnostics;
using LabCliente.Models;
using BoldReports.RDL.DOM;
using BoldReports.Writer;
using FastReport;
using FastReport.Export.Pdf;
using FastReport.Web;
using Microsoft.Extensions.Caching.Memory;
using BoldReports.Web.ReportViewer;
using Microsoft.Reporting.WebForms;
using ProcessingMode = BoldReports.Web.ReportViewer.ProcessingMode;
using System.IO;
using Microsoft.ReportingServices.Interfaces;

namespace LabCliente.Controllers
{
    public class RelController : Controller
    {
        public readonly IWebHostEnvironment _webHostEnv;
        private readonly IClienteService _clienteService;
        private Microsoft.AspNetCore.Hosting.IWebHostEnvironment _hostingEnvironment;
        



        // Report Viewer requires a memory cache to store the information of consecutive client requests 
        //and have the rendered Report Viewer information in the server.
        private Microsoft.Extensions.Caching.Memory.IMemoryCache _cache;

        // IWebHostEnvironment used with sample to get the application data from wwwroot.
        

        // Post action to process the report from server-based JSON parameters and send the result back to the client.
        public RelController(Microsoft.Extensions.Caching.Memory.IMemoryCache memoryCache, IWebHostEnvironment webHostEnv,
        Microsoft.AspNetCore.Hosting.IWebHostEnvironment hostingEnvironment)
        {
            _cache = memoryCache;
            _webHostEnv = webHostEnv;
            
            _hostingEnvironment = hostingEnvironment;
        }

        // Post action to process the report from server-based JSON parameters and send the result back to the client.
        [HttpPost]
        public object PostReportAction([FromBody] Dictionary<string, object> jsonArray)
        {
            //Contains helper methods that help process a Post or Get request from the Report Viewer control and return the response to the Report Viewer control.
            return ReportHelper.ProcessReport(jsonArray, (IReportController)this, this._cache);
        }

        // Method will be called to initialize the report information to load the report with ReportHelper for processing.
        [NonAction]
        public void OnInitReportOptions(ReportViewerOptions reportOption)
        {
            string basePath = _hostingEnvironment.WebRootPath;
            // Here, we have loaded the sales-order-detail.rdl report from the application folder wwwroot\Resources. The sales-order-detail.rdl file should be in the wwwroot\Resources application folder.
            FileStream inputStream = new FileStream(basePath
            + "\\Resources\\" + reportOption.ReportModel.ReportPath,
            FileMode.Open, FileAccess.Read);
            MemoryStream reportStream = new MemoryStream();
            inputStream.CopyTo(reportStream);
            reportStream.Position = 0;
            inputStream.Close();
            reportOption.ReportModel.Stream = reportStream;
        }

        // Method will be called when report is loaded internally to start to layout process with ReportHelper.
        [NonAction]
        public void OnReportLoaded(ReportViewerOptions reportOption)
        {
        }

        //Get action for getting resources from the report.
        [ActionName("GetResource")]
        [AcceptVerbs("GET")]
        // Method will be called from Report Viewer client to get the image src for the Image report item.
        public object GetResource(ReportResource resource)
        {
            return ReportHelper.GetResource(resource, (IReportController)this, _cache);
        }

        [HttpPost]
        public object PostFormReportAction()
        {
            return ReportHelper.ProcessReport(null, (IReportController)this, _cache);
        }
        public IActionResult Index()
        {
            return View();
        }

        [Route("CreateReport")]
        public IActionResult CreateReport()
        {
            var caminhoReport = Path.Combine(_webHostEnv.WebRootPath, @"reports\ReportMvc.frx");
            var reportFile = caminhoReport;
            var freport = new FastReport.Report();
            var productList = _clienteService.GetCliente();

            freport.Dictionary.RegisterBusinessObject(productList, "productList", 10, true);
            freport.Report.Save(reportFile);

            return Ok($" Relatorio gerado : {caminhoReport}");
        }

        [Route("ProductsReport")]
        public IActionResult ProductsReport()
        {

            var caminhoReport = Path.Combine(_webHostEnv.WebRootPath, @"reports\ReportMvc.frx");
            var reportFile = caminhoReport;
            var freport = new FastReport.Report();
            var productList = _clienteService.GetCliente();

            freport.Report.Load(reportFile);
            freport.Dictionary.RegisterBusinessObject(productList, "productList", 10, true);
            //freport.Report.Save(reportFile);
            freport.Prepare();
            PDFExport pdfExport = new PDFExport();
            // For export to PDF/A format
            //pdfExport.PdfCompliance = PDFExport.PdfStandard.PdfA_2a;
            // You can select the desired compliance level


           freport.Prepare();





            
           

            using MemoryStream ms = new MemoryStream();
            pdfExport.Export(freport, ms);
            ms.Flush();

            return File(ms.ToArray(), "application/pdf");
            //return Ok($"Relatorio gerado: {caminhoReport}");
            /*
            var contentType = "application/pdf";
            var fileDownloadName = "report.pdf";
            
            var caminhoReport = Path.Combine(_webHostEnv.WebRootPath, @"reports\ReportMvc.frx");
            var reportFile = caminhoReport;
            var freport = new Report();
            var clienteList = _clienteService.GetCliente();

            freport.Dictionary.RegisterBusinessObject(clienteList, "clienteList", 10, true);
            freport.Report.Save(reportFile);



            freport.Report.Load(reportFile);
            freport.Dictionary.RegisterBusinessObject(clienteList, "clienteList", 10, true);
            freport.Prepare();

            //freport.Report.Save(reportFile);
            Report report = new Report();
            report.Load(reportFile);
            // Setting up PDF export
            PDFExport pdfExport = new PDFExport();
            // For export to PDF/A format
            //pdfExport.PdfCompliance = PDFExport.PdfStandard.PdfA_2a;
            // You can select the desired compliance level


            report.Prepare();





            var stream = new MemoryStream();
            freport.Export(pdfExport, stream);
            stream.Position = 1;

            return File(stream, contentType, fileDownloadName);
            */
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult PrintPDF()
        {






            var rdlPath = "\\Resources\\labClientes.rdl";
            FileStream inputStream = new(_hostingEnvironment.WebRootPath +
            rdlPath, FileMode.Open, FileAccess.Read);
            BoldReports.Writer.ReportWriter writer = new BoldReports.Writer.ReportWriter();
            writer.LoadReport(inputStream);
            using MemoryStream memoryStream = new();
            writer.Save(memoryStream, BoldReports.Writer.WriterFormat.PDF);
            //return File(memoryStream.ToArray(), "application/pdf", "example.pdf");

            
            

            return File(memoryStream.ToArray(), "application/pdf");














            /*

            

            var rdlPath = "\\Resources\\labClientes.rdl";
            FileStream inputStream = new(_hostingEnvironment.WebRootPath +
            rdlPath, FileMode.Open, FileAccess.Read);
            BoldReports.Writer.ReportWriter writer = new BoldReports.Writer.ReportWriter();
            writer.LoadReport(inputStream);
            using MemoryStream memoryStream = new();
            writer.Save(memoryStream, BoldReports.Writer.WriterFormat.PDF);
            return File(memoryStream.ToArray(), "application/pdf", "example.pdf");

           */

            /*
             * private void btnGerar_Click(object sender, EventArgs e)
        {
            ReportViewer reportViewer = new ReportViewer();
            reportViewer.ProcessingMode = ProcessingMode.Local;
            reportViewer.LocalReport.ReportEmbeddedResource = "Apresentacao.FichaIndividualRelatorio.rdlc";
            List<ReportParameter> listReportParameter = new List<ReportParameter>();
            listReportParameter.Add(new ReportParameter("PORT", lblPort.Text));
            listReportParameter.Add(new ReportParameter("INGL", lblIngles.Text));
            listReportParameter.Add(new ReportParameter("GEOG", lblGeo.Text));
            listReportParameter.Add(new ReportParameter("HIST", lblHist.Text));
            reportViewer.LocalReport.SetParameters(listReportParameter);
            
            
            Warning[] warning;
            string[] streamids;
            string nineType;
            string encoding;
            string extension;
            byte[] bytePDF = reportViewer.LocalReport.Render("Pdf", null, out nineType, out encoding, out extension, out streamids, out warning);
            FileStream fileStreamPdf = null;
            string nomeArquivoPdf = Path.GetTempPath() + "FichaIndividual" + DateTime.Now.ToString("dd_MM_yyyy-HH_mm_ss")+".pdf";
            fileStreamPdf = new FileStream(nomeArquivoPdf, FileMode.Create);
            fileStreamPdf.Write(bytePDF, 0, bytePDF.Length);
            fileStreamPdf.Close();
            Process.Start(nomeArquivoPdf);
        }
             */


        }


    }
}
