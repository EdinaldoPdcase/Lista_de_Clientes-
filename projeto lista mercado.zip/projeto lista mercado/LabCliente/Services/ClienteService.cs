﻿using LabCliente.Context;
using LabCliente.Models;

namespace LabCliente.Services;

public class ClienteService : IClienteService
{
    private readonly AppDbContext _context;
    public ClienteService(AppDbContext context)
    {
        _context = context;
    }

    public List<Cliente> GetCliente()
    {
        var clientes = _context.Cliente.ToList();
        return clientes;
    }
}
