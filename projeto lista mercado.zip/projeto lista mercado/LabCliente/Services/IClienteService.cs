﻿using LabCliente.Models;

namespace LabCliente.Services;

public interface IClienteService
{
    List<Cliente> GetCliente();
}
