﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Projeto_Mercado.Models;

namespace ProjetoMercado.Models
{
    
    public class Tb_Produtos
    {
        [Key]
        [Display(Name = "Id")]
        public int ProdutoID { get; set; }
        [Required(ErrorMessage = "Informe o nome do produto")]
        public string NomeProduto { get; set; }
        [Required(ErrorMessage = "Informe o preço de custo!")]
        [Column(TypeName = "decimal(10,2)")]
        public float PrecoDeCusto { get; set; }
        [Required(ErrorMessage = "Informe o preço de venda!")]
        [Column(TypeName = "decimal(10,2)")]
        public float PrecoDeVenda { get; set; }
        [Range(0, 2, ErrorMessage = "Medição Inválida")]
        public int Medicao { get; set; }
        public bool Status { get; set; }
        public DateTime DataProduto { get; set; }

        public int CategoriaID { get; set; }
        public virtual Tb_Categoria Categoria { get; set; }
        public int ProdutoIDEstoqueID { get; set; }
        public virtual Tb_Estoque Estoque { get; set; }
        public int FonecedorID { get; set; }
        public virtual List<Tb_Fornecedor> Fornecedores { get; set; }
        public int PromocaoID { get; set; }
        public virtual Tb_Promocao Promocao { get; set; }
        public int VendasID { get; set; }
        public virtual List<Tb_Venda> Vendas { get; set; }


    }
}
