﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Categoria
    {
        [Key]
        [Required]
        public int CategoriaID { get; set; }
        [Required(ErrorMessage = "Digite nome da categoria")]
        [StringLength(100, ErrorMessage = "Nome muito grande.")]
        [MinLength(2, ErrorMessage = "Precisa ter no mínimo 2 caracteres.")]
        public string Nome { get; set; }
        public bool Status { get; set; }

        public int ProdudoID { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }

    }
}
