﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Venda
    {
        [Key]
        public int VendaID { get; set; }
        public DateTime Data { get; set; }
        public float Total { get; set; }
        public float ValorPago { get; set; }
        public float Troco { get; set; }
        public int ProdutoId { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }
    }
}
