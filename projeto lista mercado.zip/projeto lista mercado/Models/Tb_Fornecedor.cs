﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Fornecedor
    {
        [Key]
        [Required]
        public int FonecedorID { get; set; }
        [Required(ErrorMessage = " Esse campo é obrigatório ")]
        public string Nome { get; set; }
        [Required(ErrorMessage = " Esse campo é obrigatório ")]
        [EmailAddress(ErrorMessage = "Digite um email válido")]
        public string Email { get; set; }
        [Required(ErrorMessage = " Esse campo é obrigatório ")]
        [Phone(ErrorMessage = "Digite um Telfone Válido")]
        public string Telefone { get; set; }
        public bool Status { get; set; }

        public int ProdudoID { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }
    }
}
