﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Saida
    {
        [Key]
        public int SaidaID { get; set; }
        public float Quantidade { get; set; }
        public float ValorDaVenda { get; set; }
        public DateTime Data { get; set; }
        public int VendaID { get; set; }
        public virtual List<Tb_Venda> Vendas { get; set; }
        public int ProdutoId { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }
    }
}
