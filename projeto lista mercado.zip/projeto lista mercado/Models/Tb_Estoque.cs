﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Estoque
    {
        [Key]
        public int ProdutoIDEstoque { get; set; }
        public float Quantidade { get; set; }
        public int ProdutoId { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }
    }
}
