﻿using ProjetoMercado.Models;
using System.ComponentModel.DataAnnotations;

namespace Projeto_Mercado.Models
{
    public class Tb_Promocao
    {
        [Key]
        public int PromocaoID { get; set; }

        public string Nome { get; set; }

        public float Porcentagem { get; set; }

        public bool Status { get; set; }
        public int ProdutoId { get; set; }
        public virtual List<Tb_Produtos> Produtos { get; set; }

    }
}
