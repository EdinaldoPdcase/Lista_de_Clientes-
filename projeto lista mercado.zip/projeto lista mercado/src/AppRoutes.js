import { Counter } from "./components/Counter";
import { FetchData } from "./components/FetchData";
import { FetchProdutos } from "./components/FetchProdutos";
import { Home } from "./components/Home";

const AppRoutes = [
  {
    index: true,
    element: <Home />
  },
  {
    path: '/counter',
    element: <Counter />
  },
  {
    path: '/fetch-data',
    element: <FetchData />
    },
    {
        path: '/fetch-produto',
        element: <FetchProdutos />
    }
];

export default AppRoutes;
