﻿import React, { Component } from 'react';

export class Produtos {
    constructor() {
        this.ProdutoID = 0;
        this.Path = "";
    }
}

export class AddProdutos extends Component {
    constructor(props) {
        super(props);
        this.state = { title: "", Tb_Produtos: new Produtos(), loading: true };
        this.intialize();

        this.handleSalve = this.handleSalve.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
    }

    async intialize() {

        var ProdutoID = this.props.match.params["ProdutoID"];
        if (ProdutoID > 0) {
            const response = await fetch('api/Produtos/' + ProdutoID);
            const data = await response.json();
            this.setState({ title: "Edit", Tb_Produtos: data, loading: false });
        }
        else {

            this.state = { title: "Create", Tb_Produtos: new Produtos(), loading: false };
        }
    }

    render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p>
            : this.renderCreateForm();

        return (
            <div>
                <h1>{this.state.title}</h1>
                <h3>Produtos</h3>
                {contents}
            </div>
        );
    }


    handleSalve(event) {
        event.preventDefault();

        const data = new FormData(event.target);

        if (this.state.Tb_Produtos.ProdutoID) {
            const response1 = fetch('api/Produtos/' + this.state.Tb_Produtos.ProdutoID, { method: 'PUT', body: data });
            this.props.history.push('/fetch-produto');
        }
        else {
            const response2 = fetch('api/Produtos/', { method: 'POST', body: data });
            this.props.history.push('/fetch-produto');
        }
    }

    handleCancel(event) {
        event.preventDefault();
        this.props.history.push('/fetch-produto');
    }

    renderCreateForm() {
        return (
            <form onSubmit={this.handleSalve}>
                <div className="form-group row">
                    <label class="control-label">Sorteio</label>
						<input type="text" name="NomeProduto" placeholder="Digite o nome do produto" class="form-control" />
                </div>
                <div className="form-group row">
                    <label class="control-label">Sorteio</label>
                    <input type="decimal" name="preco" placeholder="Digite o preço do produto" class="form-control" />
                </div>
                <div className="form-group row">
                    <label class="control-label">Sorteio</label>
                    <input type="text" name="categoria" placeholder="Digite a categoria do produto" class="form-control" />

                    <div className="form-group row">
                        <label class="control-label">Sorteio</label>
                        <input type="number" name="num_estoque" placeholder="Digite a quantidade em estoque do produto" class="form-control" />
                    </div>
                    <div className="form-group row">
                        <label class="control-label">Sorteio</label>
                        <input type="text" name="fornecedor" placeholder="Digite o nome do fornecedor produto" class="form-control" />
                    </div>


                </div>


                <div className="form-group">
                    <button type="submit" className="btn btn-success" value={this.state.Tb_Produtos.ProdutoID}>Salvar</button>
                    <button className="btn btn-danger" onClick={this.handleCancel}>Cencelar</button>
                </div>
            </form>

        );
    }

}


