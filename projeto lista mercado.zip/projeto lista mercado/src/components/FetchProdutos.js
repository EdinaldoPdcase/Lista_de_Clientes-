﻿import React, { Component } from "react"

export class FetchProdutos extends Component {
    static displayName = FetchProdutos.name;

    constructor() {
        super();
        this.state = { produtos: [], loading: true }
    }

    componentDidMount() {
        this.populaProdutosData();
    }

    

    

    static renderProdutosTabela(produtos) {

        return (
            <table className='table table-striped' aria-labelledby="tabelLabel" >
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>M</th>
                        <th>Data</th>
                    </tr>
                </thead>
                <tbody>
                  
                    {produtos.map(produto =>
                        <tr key={produto.ProdutoID}>
                            <td>{produto.ProdutoID}</td>
                            <td>{produto.NomeProduto}</td>
                            <td>{produto.PrecoDeVenda}</td>

                            
                        </tr>

                    )}
                </tbody>
            </table>
        );

    }

    render() {
        let contents = this.state.loading
            ? <p><em> Carregando... </em> </p>
            : FetchProdutos.renderProdutosTabela(this.state.produtos);

        return (
            <div>
                <h1 id="tabelLabel" >Produtos</h1>
                <p>Tela de Listagem de Impedidos</p>
                
                {contents}
            </div>
        );
    }


    async populaProdutosData() {
        const response = await fetch('https://localhost:7004/Produtos/GetprodutosList');
        const data = await response.json();
        this.setState({ produtos: data, loading: false });
        console.log(data);
    }
}

