﻿using ImportaSorteioImpedidos.Models;

namespace ImportaSorteioImpedidos.Repositories.Interfaces
{
    public interface ICrudRepo
    {

    }
}
