﻿using ImportaSorteioImpedidos.Context;
using ImportaSorteioImpedidos.Models;

namespace ImportaSorteioImpedidos.Repositories.Interfaces
{
    public interface IPpImpedidosRepository
    {

        public IEnumerable<PpImpedidos> GetImpedidos(int SorteioID, decimal CPF, String Motivo, String DataImpedimento);
        public int ImportImpedidos(int SorteioID, string Path);
        public Task<List<PpImpedidos>> GetPpi();
        public IEnumerable<PpImpedidos> UpdateImp(int SorteioID, String Motivo, String DataImpedimento);
        
    }
}
