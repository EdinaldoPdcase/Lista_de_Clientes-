﻿using ImportaSorteioImpedidos.Context;
using ImportaSorteioImpedidos.Models;
using ImportaSorteioImpedidos.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace ImportaSorteioImpedidos.Repositories
{
    public class PpImpedidosrepository: IPpImpedidosRepository  
    {
        private readonly AppDbContext context;
        public PpImpedidosrepository(AppDbContext contexto)
        {
            context = contexto;
        }
        public IEnumerable<PpImpedidos> UpdateImp(int SorteioID, String Motivo, String DataImpedimento)
        {

            var param1 = new SqlParameter("@SorteioID", SorteioID);
            var param2 = new SqlParameter("@Motivo", Motivo);
            var param3 = new SqlParameter("@DataImpedimento", DataImpedimento);

            var datb = Task.Run(() => context.PpImpedidos
                            .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());
            return (IEnumerable<PpImpedidos>)datb;
        }
        public IEnumerable<PpImpedidos> GetImpedidos(int SorteioID, decimal CPF, String Motivo, String DataImpedimento)
        {
            var param1 = new SqlParameter("@SorteioID", SorteioID);
            var param2 = new SqlParameter("@Motivo", Motivo);
            var param3 = new SqlParameter("@DataImpedimento", DataImpedimento);
            var Impedido = context.PpImpedidos.FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync();
            return (IEnumerable<PpImpedidos>)Impedido;
        }

        public int ImportImpedidos(int SorteioID, string Path)
        {
            int @ROWCOUNT = context.Database.ExecuteSqlInterpolated($"EXEC sp_Inserecsv {SorteioID}, {@Path}");
            return @ROWCOUNT;
        }

        public async Task<int> CreateImpedidoAsync(int SorteioID, String @Path)
        {


            var parameter = new List<SqlParameter>
            {
                new SqlParameter("@SorteioID", SorteioID),
                new SqlParameter("@Path", Path)
            };
            var result = await Task.Run(() => context.PpImpedidos.FromSqlRaw(@"exec sp_Inserecsv 
                                                            @SorteioID,
                                                            @Path",
                                                            parameter.ToArray()
                                                            ));

            return 0;


        }

        public async Task<List<PpImpedidos>> GetPpi()
        {
            List<PpImpedidos> Impedidos = new List<PpImpedidos>();
            var result = await context.PpImpedidos.FromSqlRaw(@"exec EditaPpImpedidos").ToListAsync();

            foreach (var row in result)
            {
                Impedidos.Add(new PpImpedidos
                {
                    SorteioID = row.SorteioID,
                    CPF = row.CPF,
                    Motivo = row.Motivo,
                    DataImpedimento = row.DataImpedimento
                });
            }
            return Impedidos;
        }
    }
}
