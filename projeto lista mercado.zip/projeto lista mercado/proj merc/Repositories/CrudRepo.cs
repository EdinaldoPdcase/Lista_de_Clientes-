﻿using ImportaSorteioImpedidos.Models;
using Microsoft.Data.SqlClient;
using ImportaSorteioImpedidos.Context;

using ImportaSorteioImpedidos.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;


namespace ImportaSorteioImpedidos.Repositories
{
    public class CrudRepo : ICrudRepo
    {
        private readonly ICrudRepo context;
        public CrudRepo(ICrudRepo repository)
        {
            context = repository;

        }
        
    }
}
