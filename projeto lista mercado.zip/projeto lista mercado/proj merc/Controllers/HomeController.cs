﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ImportaSorteioImpedidos.Context;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using ImportaSorteioImpedidos.Repositories;
using Microsoft.CodeAnalysis;
using ImportaSorteioImpedidos.Models;
using System.Net;
using System.Linq;
using NuGet.Protocol.Core.Types;
using ImportaSorteioImpedidos.Repositories.Interfaces;
using Humanizer;
using System.Reflection.Metadata;

namespace ImportaSorteioImpedidos.Controllers
{
    public class HomeController : Controller
    {
        
        private readonly AppDbContext storeDB;


        public HomeController(AppDbContext context)
        {
            storeDB = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await storeDB.PpImpedidos.OrderBy(c => c.SorteioID).ToListAsync());
        }

        /*
         public async Task<ActionResult<PpImpedidos>> GetImpedidos()
         {
             var result = await _repository.GetPpi();
             return Ok(result);
         } 
        */


        /*public async Task<ActionResult<int>> CreateImpedidos(int SorteioID, String @Path)
        {
            var result = await _repository.importImpedidos(SorteioID, Path);
            return Ok(result);
        }*/

        public async Task<IActionResult> Create(int @SorteioID, String @Path)
        {
            int @ROWCOUNT = storeDB.Database.ExecuteSqlInterpolated($"EXEC sp_Inserecsv {SorteioID}, {@Path}");

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());

        }
        public async Task<IActionResult> Edit(int SorteioID)
        {
            
          
        

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
            
        }

        // POST: Dicpoups/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int SorteioID, [Bind("Motivo, DataImpedimento")] PpImpedidos Ppi)
        {
           

            var param1 = new SqlParameter("@SorteioID", SorteioID);
                var param2 = new SqlParameter("@Motivo", Ppi.Motivo);
                var param3 = new SqlParameter("@DataImpedimento", Ppi.DataImpedimento);

                var datb = await Task.Run(() => storeDB.PpImpedidos
                                .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());


               
           
            return RedirectToAction("Index");
        }
             
    

        /*
    public async Task<ActionResult> Edit(int @SorteioID)

    {

        

 

        // Pertistir dados até o próximo request.

        TempData["sorteio"] = SorteioID;



            // Redirect entre Controllers

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == SorteioID).ToListAsync());

        }



        */



        // GET: /Medico/Edit/5
        /*public ActionResult Edita(int? SorteioID)
                {

                    //return RedirectToAction("Edita", new { SorteioID = SorteioID });
                    //return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());


                }*/
        /*
                // POST: /Medico/Edit/5
                // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
                // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
                [HttpPost]
                [ValidateAntiForgeryToken]
                public async Task<ActionResult> Edit([Bind("SorteioID, Motivo,DataImpedimento")] PpImpedidos impedidos)
                {
                    if (ModelState.IsValid)
                    {
                        var SorteioID = TempData["sorteio"];
                        var param1 = new SqlParameter("@SorteioID", SorteioID);
                        var param2 = new SqlParameter("@Motivo", impedidos.Motivo);
                        var param3 = new SqlParameter("@DataImpedimento", impedidos.DataImpedimento);

                        var datb = await Task.Run(() => storeDB.PpImpedidos
                                        .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());


                        return RedirectToAction("Index");
                    }
                    return View(impedidos);
                }


                */
        // GET: Employees/Edit/5

        /*
        public async Task<IActionResult> Edit(int SorteioID)
        {


       

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
        }


        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int SorteioID, [Bind("Motivo,DataImpedimento")] PpImpedidos Imped)
        {
           
         
            var param1 = new SqlParameter("@SorteioID", SorteioID);
            var param2 = new SqlParameter("@Motivo", Imped.Motivo);
            var param3 = new SqlParameter("@DataImpedimento", Imped.DataImpedimento);

            var datb = await Task.Run(() => storeDB.PpImpedidos
                            .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());



            return RedirectToAction("Index");





        }


        */
        // GET: Compras1/Edit/5


        /*
         public async Task<IActionResult> Edit(int SorteioID)
         {




             return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
         }


         // POST: Compras1/Edit/5
         // To protect from overposting attacks, enable the specific properties you want to bind to.
         // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
         [HttpPost]
         public async Task<IActionResult> Edit(int SorteioID, [Bind("Motivo,DataImpedimento")] PpImpedidos Ppi)
         {


             storeDB.Database.ExecuteSqlInterpolated($"EXEC EditaPpImpedidos {SorteioID}, {Ppi.Motivo}, {Ppi.DataImpedimento}");



             return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
         }
        */
    }
}
