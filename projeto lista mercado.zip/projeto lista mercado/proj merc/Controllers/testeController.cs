﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ImportaSorteioImpedidos.Context;
using Microsoft.Data.SqlClient;

using Microsoft.CodeAnalysis;
using ImportaSorteioImpedidos.Models;
using System.Net;
using System.Linq;

namespace ImportaSorteioImpedidos.Controllers
{
    public class testeController : Controller
    {
        private readonly AppDbContext storeDB;


        public testeController(AppDbContext context)
        {
            storeDB = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await storeDB.PpImpedidos.OrderBy(c => c.SorteioID).ToListAsync());
        }

        public async Task<IActionResult> Create(int @SorteioID, String @Path)
        {
            int @ROWCOUNT = storeDB.Database.ExecuteSqlInterpolated($"EXEC sp_Inserecsv {SorteioID}, {@Path}");

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());

        }
        
        public async Task<ActionResult> Edit(int SorteioID)
        {


            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
        }

        [HttpPost]
        public async Task<ActionResult> Edit(PpImpedidos sorteio, [Bind("Motivo,DataImpedimento")] PpImpedidos Ppi)
        {
            var param1 = new SqlParameter("@SorteioID", sorteio.SorteioID);
            var param2 = new SqlParameter("@Motivo", Ppi.Motivo);
            var param3 = new SqlParameter("@DataImpedimento", Ppi.DataImpedimento);

            var datb = await Task.Run(() => storeDB.PpImpedidos
                            .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());


            return RedirectToAction("Index");
        }
        
        /*
        public async Task<IActionResult> Edit(int SorteioID,PpImpedidos model, decimal CPF, String Motivo, String DataImpedimento)
        {
            
            var param1 = new SqlParameter("@SorteioID", SorteioID);
            var param2 = new SqlParameter("@Motivo", Motivo);
            var param3 = new SqlParameter("@DataImpedimento", DataImpedimento);

            var datb = await Task.Run(() => storeDB.PpImpedidos
                            .FromSqlRaw(@"exec EditaPpImpedidos @SorteioID, @Motivo, @DataImpedimento", param1, param2, param3).ToListAsync());
            */
        /*
         if (Motivo != null)
         {
             storeDB.Database.ExecuteSqlInterpolated($"EXEC EditaPpImpedidos {SorteioID}, {Motivo}, {DataImpedimento}");
         }
         return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == SorteioID).ToListAsync());

     }*/

        // GET: Compras1/Edit/5
        /*
        public async Task<IActionResult> Edit(int? SorteioID, PpImpedidos PpI)
        {
           
            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
        }

        // POST: Compras1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Edit(int SorteioID, [Bind("Motivo,DataImpedimento")] PpImpedidos Ppi)
        {
            
            
               storeDB.Database.ExecuteSqlInterpolated($"EXEC EditaPpImpedidos {SorteioID}, {Ppi.Motivo}, {Ppi.DataImpedimento}");
            
            

            return View(await storeDB.PpImpedidos.Where(c => c.SorteioID == @SorteioID).ToListAsync());
        }

        public IActionResult Edita(int SorteioID, PpImpedidos model, decimal CPF, String Motivo, String DataImpedimento)
        {
            
            return View();


        }
        */
    }
}