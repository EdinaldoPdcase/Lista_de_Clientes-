﻿using ImportaSorteioImpedidos.Models;
using ImportaSorteioImpedidos.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ImportaSorteioImpedidos.Controllers
{
    public class CrudImpedidosController : Controller
    {
        private readonly IPpImpedidosRepository _repository;
        public CrudImpedidosController(IPpImpedidosRepository repository)
        {
            _repository = repository;

        }
        public IActionResult Index()
        {
            return View();
        }
        
        

        public async Task<ActionResult<PpImpedidos>> GetImpedidos()
        {
            var result = await _repository.GetPpi();
            return Ok(result);
        }


        public ActionResult<PpImpedidos> CreateImpedidos(int SorteioID, String @Path)
        {
            var result = _repository.ImportImpedidos(SorteioID, Path);
            return Ok(GetImpedidos());
        }

        

        // GET: Compras1/Edit/5




        // POST: Compras1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

    }
}
