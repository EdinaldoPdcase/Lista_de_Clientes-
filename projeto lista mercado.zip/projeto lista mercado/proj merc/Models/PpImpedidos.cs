﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace ImportaSorteioImpedidos.Models
{
    [PrimaryKey(nameof(SorteioID), nameof(CPF))]
    public class PpImpedidos
    {
        

        [Required(ErrorMessage = "Informe o SorteioID!")]
        [Display(Name = "SorteioID")]
        public int SorteioID { get; set; }
        [Required(ErrorMessage = "Informe o CPF do cliente!")]
        [Column(TypeName = "decimal(14,0)")]
        public decimal CPF { get; set; }

        [Required(ErrorMessage = "Digite MOTIVO")]
        [StringLength(160)]
        public string? Motivo { get; set; }
        public DateTime DataImpedimento { get; set; }
        
    }
}
