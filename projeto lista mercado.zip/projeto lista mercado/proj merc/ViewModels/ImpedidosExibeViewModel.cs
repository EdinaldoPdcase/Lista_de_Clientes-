﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace ImportaSorteioImpedidos.ViewModels
{
    [PrimaryKey(nameof(SorteioID), nameof(CPF))]
    public class ImpedidosExibeViewModel
    {
        [Required(ErrorMessage = "Informe o SorteioID!")]
        [Display(Name = "SorteioID")]
        public int SorteioID { get; set; }
        [Column(TypeName = "decimal(14,0)")]
        public decimal CPF { get; set; }
    }
}
