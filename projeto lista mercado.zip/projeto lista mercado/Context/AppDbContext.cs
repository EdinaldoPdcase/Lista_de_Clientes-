﻿using ProjetoMercado.Models;
using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace ProjetoMercado.Context
{
    public class AppDbContext : DbContext
    {    
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        { }
       
        public DbSet<Tb_Produtos> Tb_Produtos { get; set; }
       
    }
}
