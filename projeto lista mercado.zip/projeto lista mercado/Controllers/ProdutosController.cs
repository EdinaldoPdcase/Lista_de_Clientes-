﻿using ProjetoMercado.Models;
using ProjetoMercado.Repositorio;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace ProjetoMercado.Controllers
{
    [EnableCors("mypolicy")]
    [ApiController]
    [Route("[controller]")]
    public class ProdutosController : Controller
    {
        private readonly ICrudProdutos produtos;

        public ProdutosController(ICrudProdutos produtos)
        {
            this.produtos = produtos;
        }
        [HttpGet]
        [Route("GetProdutosList")]
        public async Task<List<Tb_Produtos>> GetProdutosList()
        {
            try
            {
                return await produtos.GetProdutosListAsync();
            }
            catch
            {
                throw;
            }
        }

        [HttpGet("{ProdutoID}")]
        public async Task<IEnumerable<Tb_Produtos>> GetByProdutoIDAsync(int ProdutoID)
        {
            try
            {
                var response = await produtos.GetProdutoByProdutoIDAsync(ProdutoID);

                if (response == null)
                {
                    return null;
                }

                return response;
            }
            catch
            {
                throw;
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddProdutosAsync(Tb_Produtos produtos)
        {
            try
            {
                var response = await AddProdutosAsync(produtos);

                if (response == null)
                {
                    return null;
                }

                return response;
            }
            catch
            {
                throw;
            }




            
        }

        [HttpPut("{SorteioID}")]
        public async Task<IActionResult> UpdateprodutostAsync(Tb_Produtos produtos)
        {
            if (produtos == null)
            {
                return BadRequest();
            }

            try
            {
                var result = await UpdateprodutostAsync(produtos);
                return Ok(result);
            }
            catch
            {
                throw;
            }
        }

        [HttpDelete("{SorteioID}")]
        public async Task<int> DeleteprodutosAsync(int ProdutoID)
        {
            try
            {
                var response = await produtos.DeleteProdutoAsync(ProdutoID);
                return response;
            }
            catch
            {
                throw;
            }
        }
    }
}
